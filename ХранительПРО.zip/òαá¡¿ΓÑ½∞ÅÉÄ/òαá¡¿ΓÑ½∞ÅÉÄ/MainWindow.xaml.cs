﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ХранительПРО
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_authorization_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new ХранительПРО_КвакинEntities())
            {
                var users = db.Пользователь.FirstOrDefault(Пользователь => Пользователь.логин == textbox_login.Text.ToString() && Пользователь.пароль == textbox_password.Text.ToString());
                if (users == null)
                    MessageBox.Show("Неверно введен логин или пароль");
                else
                {
                    WindowTypeVisit tv = new WindowTypeVisit();
                    tv.Show();
                    this.Close();
                }
            }
        }

        private void btn_registration_Click(object sender, RoutedEventArgs e)
        {
            WindowRegistration reg = new WindowRegistration();
            reg.Show();
            this.Close();
        }
    }
}
