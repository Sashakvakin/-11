﻿using System;

using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Data.SqlClient;
namespace ТЕРМИНАЛ_СОТРУДНИКА_ОБЩЕГО_ОТДЕЛА
{
    /// <summary>
    /// Логика взаимодействия для WindowProsmotrZaiavok.xaml
    /// </summary>
    public partial class WindowProsmotrZaiavok : Window
    {
        private const string connectionString = @"Data Source=KAB17-05\SQLEXPRESS;Initial Catalog=ХранительПРО_Квакин;Integrated Security=True;"; /// ///
        /// </summary>
        public WindowProsmotrZaiavok()
        {
            InitializeComponent();
            FillDataGridZaiawki();
        }
        private void FillDataGridZaiawki()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Фильтрация по id_статуса_заявки = 2
                string sqlQuery = @"SELECT id_заявки, id_посетителя, id_сотрудника, дата_подачи, дата_начала_действия_пропуска, дата_окончания_действия_пропуска, id_статуса_заявки, цель_посещения
                FROM Заявка
                WHERE id_статуса_заявки = 1"; // Добавлены цель_посещения и id_статуса_заявки

                using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        // Очистка существующих столбцов
                        DataGridZaiawki.Columns.Clear();

                        // Определение заголовков и привязки столбцов
                        DataGridTextColumn idZayavkiColumn = new DataGridTextColumn();
                        idZayavkiColumn.Header = "ID заявки";
                        idZayavkiColumn.Binding = new Binding("IdZayavki");
                        DataGridZaiawki.Columns.Add(idZayavkiColumn);

                        DataGridTextColumn idPosetitelyaColumn = new DataGridTextColumn();
                        idPosetitelyaColumn.Header = "ID посетителя";
                        idPosetitelyaColumn.Binding = new Binding("IdPosetitelya");
                        DataGridZaiawki.Columns.Add(idPosetitelyaColumn);

                        DataGridTextColumn idSotrudnikaColumn = new DataGridTextColumn();
                        idSotrudnikaColumn.Header = "ID сотрудника";
                        idSotrudnikaColumn.Binding = new Binding("IdSotrudnika");
                        DataGridZaiawki.Columns.Add(idSotrudnikaColumn);

                        DataGridTextColumn dataPodachiColumn = new DataGridTextColumn();
                        dataPodachiColumn.Header = "Дата подачи";
                        // Отображение даты в удобочитаемом формате (может потребоваться форматирование)
                        dataPodachiColumn.Binding = new Binding("DataPodachi") { StringFormat = "{0:dd.MM.yyyy}" };
                        DataGridZaiawki.Columns.Add(dataPodachiColumn);

                        DataGridTextColumn dataNachalaDeystviyaPropyskaColumn = new DataGridTextColumn();
                        dataNachalaDeystviyaPropyskaColumn.Header = "Дата начала действия пропуска";
                        // Отображение даты в удобочитаемом формате (может потребоваться форматирование)
                        dataNachalaDeystviyaPropyskaColumn.Binding = new Binding("DataNachalaDeystviyaPropyska") { StringFormat = "{0:dd.MM.yyyy}" };
                        DataGridZaiawki.Columns.Add(dataNachalaDeystviyaPropyskaColumn);

                        DataGridTextColumn dataOkonchaniyaDeystviyaPropyskaColumn = new DataGridTextColumn();
                        dataOkonchaniyaDeystviyaPropyskaColumn.Header = "Дата окончания действия пропуска";
                        dataOkonchaniyaDeystviyaPropyskaColumn.Binding = new Binding("DataOkonchaniyaDeystviyaPropyska") { StringFormat = "{0:dd.MM.yyyy}" };
                        DataGridZaiawki.Columns.Add(dataOkonchaniyaDeystviyaPropyskaColumn);

                        // Добавлен столбец id_статуса_заявки
                        DataGridTextColumn idStatusaZayavkiColumn = new DataGridTextColumn();
                        idStatusaZayavkiColumn.Header = "ID статуса заявки";
                        idStatusaZayavkiColumn.Binding = new Binding("IdStatusaZayavki");
                        DataGridZaiawki.Columns.Add(idStatusaZayavkiColumn);

                        // Добавлен столбец цель_посещения
                        DataGridTextColumn celPoseщенияColumn = new DataGridTextColumn();
                        celPoseщенияColumn.Header = "Цель посещения";
                        celPoseщенияColumn.Binding = new Binding("CelPoseщения");
                        DataGridZaiawki.Columns.Add(celPoseщенияColumn);

                        // Добавление строк в DataGrid
                        while (reader.Read())
                        {
                            int idZayavki = reader.GetInt32(0);
                            int idPosetitelya = reader.GetInt32(1);
                            int idSotrudnika = reader.GetInt32(2);
                            DateTime dataPodachi = reader.GetDateTime(3);
                            DateTime dataNachalaDeystviyaPropyska = reader.GetDateTime(4);
                            DateTime dataOkonchaniyaDeystviyaPropyska = reader.GetDateTime(5);
                            int idStatusaZayavki = reader.GetInt32(6);
                            string celPoseщения = reader.GetString(7);

                            DataGridZaiawki.Items.Add(new { IdZayavki = idZayavki, IdPosetitelya = idPosetitelya, IdSotrudnika = idSotrudnika, DataPodachi = dataPodachi, DataNachalaDeystviyaPropyska = dataNachalaDeystviyaPropyska, DataOkonchaniyaDeystviyaPropyska = dataOkonchaniyaDeystviyaPropyska, IdStatusaZayavki = idStatusaZayavki, CelPoseщения = celPoseщения });
                        }
                    }
                }
            }
        }
        private void DataGridZaiawki_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
