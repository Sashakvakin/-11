﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;

namespace ТЕРМИНАЛ_СОТРУДНИКА_ОБЩЕГО_ОТДЕЛА
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private const string connectionString = @"Data Source=KAB17-05\SQLEXPRESS;Initial Catalog=ХранительПРО_Квакин;Integrated Security=True;"; /// ///

        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_authorization_Click(object sender, RoutedEventArgs e)
        {
            // Получим код сотрудника из TextBoxKod
            string kodSotrudnika = TextBoxKod.Text.Trim();

            // Проверим код в базе данных
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string sql = @"SELECT фамилия, имя, отчество FROM Сотрудник WHERE код_сотрудника = @kodSotrudnika AND id_отдела = 1";
                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@kodSotrudnika", kodSotrudnika);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read()) // Если код найден
                        {
                            // Получим ФИО
                            string fio = reader["фамилия"].ToString() + " " + reader["имя"].ToString() + " " + reader["отчество"].ToString();

                            // Авторизация успешна
                            MessageBox.Show($"Добро пожаловать, {fio}!");

                            // Откроем окно WindowProsmotrZaiavok
                            WindowProsmotrZaiavok windowProsmotrZaiavok = new WindowProsmotrZaiavok();
                            windowProsmotrZaiavok.Show();

                            // Закроем это окно
                            this.Close();
                        }
                        else
                        {
                            // Код не найден
                            MessageBox.Show("Неверный код сотрудника или отдел не совпадает.");
                        }
                    }
                }
            }
        }
    }
}
